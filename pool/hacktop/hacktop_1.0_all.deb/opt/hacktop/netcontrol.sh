#!/bin/bash
SCRIPTDIR="$HOME/NetControl"

clear
echo "=========== NetControl 2.0 ==========="

while true; do
  CHOICE=$(whiptail --title "NetControl 2.0" --menu "Valitse toiminto (nuolinäppäimet tai numerot):" 25 72 20     "1"  "Stealth-moodi (VPN + Tor + Kill)"     "2"  "Yhdistä VPN"     "3"  "Katkaise VPN"     "4"  "Kill-switch päälle"     "5"  "Kill-switch pois"     "6"  "Käynnistä Tor"     "7"  "Pysäytä Tor"     "8"  "Tor-testi"     "9"  "Vaihda MAC-osoite"     "10" "Nmap porttiskannaus"     "11" "Proxy-checker"     "12" "Hacker Tools"     "13" "Luo työpöytäkuvake"     "14" "Päivitä NetControl (manual)"     "15" "VPN-serverin hallinta"     "16" "VPN-clientien exportti"     "17" "DNS Leak Test"     "18" "VPN Exportien GPG-salaus"     "19" "Traffic Monitor (nload)"     "0"  "Poistu" 3>&1 1>&2 2>&3)

  case "$CHOICE" in
    1) bash "$SCRIPTDIR/netcontrol-stealth.sh" ;;
    2) bash "$SCRIPTDIR/netcontrol-vpn.sh" connect ;;
    3) bash "$SCRIPTDIR/netcontrol-vpn.sh" disconnect ;;
    4) bash "$SCRIPTDIR/netcontrol-vpn.sh" kill-on ;;
    5) bash "$SCRIPTDIR/netcontrol-vpn.sh" kill-off ;;
    6) bash "$SCRIPTDIR/netcontrol-tor.sh" start ;;
    7) bash "$SCRIPTDIR/netcontrol-tor.sh" stop ;;
    8) bash "$SCRIPTDIR/netcontrol-tor.sh" test ;;
    9) bash "$SCRIPTDIR/netcontrol-mac.sh" ;;
    10) bash "$SCRIPTDIR/netcontrol-nmap.sh" ;;
    11) bash "$SCRIPTDIR/netcontrol-proxy.sh" ;;
    12) bash "$SCRIPTDIR/netcontrol-hackertools.sh" ;;
    13) bash "$SCRIPTDIR/netcontrol-shortcut.sh" ;;
    14) bash "$SCRIPTDIR/netcontrol-update.sh" ;;
    15) bash "$SCRIPTDIR/netcontrol-vpnserver.sh" ;;
    16) bash "$SCRIPTDIR/netcontrol-export.sh" ;;
    17) bash "$SCRIPTDIR/netcontrol-dnsleak.sh" ;;
    18) bash "$SCRIPTDIR/netcontrol-gpg.sh" ;;
    19) bash "$SCRIPTDIR/netcontrol-traffic.sh" ;;
    0) exit ;;
  esac
done
