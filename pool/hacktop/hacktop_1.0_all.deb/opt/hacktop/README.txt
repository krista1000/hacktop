
██╗  ██╗ █████╗  ██████╗██╗  ██╗████████╗ ██████╗ ██████╗ 
██║  ██║██╔══██╗██╔════╝██║ ██╔╝╚══██╔══╝██╔═══██╗██╔══██╗
███████║███████║██║     █████╔╝    ██║   ██║   ██║██████╔╝
██╔══██║██╔══██║██║     ██╔═██╗    ██║   ██║   ██║██╔═══╝ 
██║  ██║██║  ██║╚██████╗██║  ██╗   ██║   ╚██████╔╝██║     
╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝     
                    HackTop by Semiko

============================================================
HackTop v1.0.0 – Secure Linux Toolkit for Ethical Hacking
============================================================

HackTop is a stealth-ready Kali Linux toolkit focused on privacy, operational security and automation for ethical use.

FEATURES:
---------
✓ VPN Integration (OpenVPN)
✓ Tor Control & Stealth Mode
✓ Kill Switch (iptables)
✓ DNS Leak Test
✓ MAC Address Randomizer
✓ GPG Encryption for VPN Exports
✓ Proxy Checker, Nmap Scanner
✓ Network Monitor (nload)
✓ Desktop shortcut creator
✓ Installer: netcontrol-setup.sh

INSTALLATION:
-------------
1. Clone the repository:
   git clone https://github.com/krista1000/hacktop.git
2. Go to the directory:
   cd hacktop
3. Make scripts executable:
   chmod +x *.sh
4. Run the installer:
   ./netcontrol-setup.sh

TERMINAL FEATURES:
------------------
• ZSH + custom HackTop ASCII banner
• Auto-launch options and neofetch

LEGAL NOTICE:
-------------
HackTop is for EDUCATIONAL and ETHICAL use only.
Do not deploy on unauthorized systems or networks.

(c) 2025 Semiko – All rights reserved.
