#!/bin/bash

if ! command -v nload &> /dev/null; then
  whiptail --msgbox "'nload' ei ole asennettuna. Asenna se komennolla:\nsudo apt install nload" 12 70
  exit 1
fi

x-terminal-emulator -e nload
