#!/bin/bash

COMMAND=$1
VPN_CONFIG="/home/kaliningrad/client-configs/files/client.ovpn"

case "$COMMAND" in
  connect)
    if sudo openvpn --config "$VPN_CONFIG" --daemon; then
      whiptail --msgbox "VPN-yhteys muodostettu." 10 50
    else
      whiptail --msgbox "VPN-yhteyden muodostus epäonnistui." 10 50
    fi
    ;;
  disconnect)
    if sudo pkill openvpn; then
      whiptail --msgbox "VPN-yhteys katkaistu." 10 50
    else
      whiptail --msgbox "Yhteyden katkaisu epäonnistui." 10 50
    fi
    ;;
  kill-on)
    sudo iptables -F
    sudo iptables -P OUTPUT DROP
    sudo iptables -A OUTPUT -o lo -j ACCEPT
    sudo iptables -A OUTPUT -o tun0 -j ACCEPT
    sudo iptables -A OUTPUT -p udp --dport 1194 -j ACCEPT
    whiptail --msgbox "Kill switch on nyt päällä." 12 60
    ;;
  kill-off)
    sudo iptables -F
    sudo iptables -P OUTPUT ACCEPT
    whiptail --msgbox "Kill switch poistettu käytöstä." 12 60
    ;;
  *)
    whiptail --msgbox "Tuntematon komento. Käytä: connect, disconnect, kill-on, kill-off" 10 60
    ;;
esac
