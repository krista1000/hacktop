#!/bin/bash

BACKUP=~/.zshrc.bak-pre-netcontrol
TARGET=~/.zshrc

if [ -f "$BACKUP" ]; then
  cp "$BACKUP" "$TARGET"
  echo "[✓] .zshrc palautettu varmuuskopiosta: $BACKUP"
else
  echo "[!] Varmuuskopiota ei löytynyt. Ei palautettu mitään."
fi
