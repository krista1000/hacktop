#!/bin/bash

# Käynnistä VPN
bash ~/NetControl/netcontrol-vpn.sh connect

# Odota hetki yhteyden muodostusta varten
sleep 5

# Käynnistä Tor
bash ~/NetControl/netcontrol-tor.sh start

# Käynnistä Kill Switchin, mutta salli selaimen liikenne esimerkiksi eth0 kautta (esim. Firefox)
# Tämä vaatii split-routingia, joka on testattava erikseen

# Perinteinen Kill Switch päälle:
# bash ~/NetControl/netcontrol-vpn.sh kill-on

# Selaamisen mahdollistamiseksi ei aseteta täyttä OUTPUT DROP -kill switchiä tässä.
# Varmistetaan että DNS toimii:
echo "nameserver 1.1.1.1" | sudo tee /etc/resolv.conf

# Tarkistusviesti
whiptail --msgbox "🛡 Stealth-moodi aktivoitu:\nVPN yhdistetty, Tor päällä, DNS ohjattu.\nVoit nyt selata internetiä turvallisesti." 12 60
