![HackTop](HackTop-Banner-COMPACT.png)

```
██╗  ██╗ █████╗  ██████╗██╗  ██╗████████╗ ██████╗ ██████╗ 
██║  ██║██╔══██╗██╔════╝██║ ██╔╝╚══██╔══╝██╔═══██╗██╔══██╗
███████║███████║██║     █████╔╝    ██║   ██║   ██║██████╔╝
██╔══██║██╔══██║██║     ██╔═██╗    ██║   ██║   ██║██╔═══╝ 
██║  ██║██║  ██║╚██████╗██║  ██╗   ██║   ╚██████╔╝██║     
╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝     
                    HackTop by Semiko
```

## HackTop v1.0.0 – Secure Linux Toolkit for Ethical Hacking

HackTop is a stealth-ready Kali Linux toolkit focused on privacy, operational security and automation for ethical use.

### 🔐 Features:
- VPN (OpenVPN) integration
- Tor control & status tester
- Kill Switch (iptables)
- DNS Leak test
- MAC Address randomizer
- GPG encryption for VPN exports
- Proxy checker, Nmap scanner
- Network monitor (nload)
- ZSH banner + system info
- Desktop shortcut
- One-command installer

### 🛠 Installation

```bash
git clone https://github.com/krista1000/hacktop.git
cd hacktop
chmod +x *.sh
./netcontrol-setup.sh
```

### ⚠️ Legal Notice

HackTop is for **educational and ethical use only**.  
Do not use on any network or system without explicit permission.

© 2025 Semiko
