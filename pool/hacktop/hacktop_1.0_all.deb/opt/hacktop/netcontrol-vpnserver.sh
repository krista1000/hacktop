#!/bin/bash

ACTION=$(whiptail --title "VPN Server" --menu "Valitse toiminto:" 20 60 7   "1" "Käynnistä OpenVPN-server"   "2" "Tarkista serverin tila"   "3" "Sammuta serveri"   "4" "Näytä serverin loki"   "5" "Käynnistä serveri uudelleen"   "0" "Takaisin" 3>&1 1>&2 2>&3)

case "$ACTION" in
  1)
    if sudo systemctl start openvpn-server@server; then
      whiptail --msgbox "✅ OpenVPN-serveri käynnistetty onnistuneesti." 10 50
    else
      whiptail --msgbox "❌ Serverin käynnistyksessä tapahtui virhe." 10 50
    fi
    ;;
  2)
    if systemctl is-active --quiet openvpn-server@server; then
      whiptail --msgbox "✅ Serveri on aktiivinen." 10 50
    else
      whiptail --msgbox "⚠️ Serveri ei ole käynnissä." 10 50
    fi
    ;;
  3)
    if sudo systemctl stop openvpn-server@server; then
      whiptail --msgbox "🛑 Serveri sammutettu onnistuneesti." 10 50
    else
      whiptail --msgbox "❌ Sammutuksessa tapahtui virhe." 10 50
    fi
    ;;
  4)
    LOGDATA=$(journalctl -u openvpn-server@server -n 20 --no-pager)
    whiptail --title "OpenVPN-server loki" --scrolltext --msgbox "$LOGDATA" 25 80
    ;;
  5)
    if sudo systemctl restart openvpn-server@server; then
      whiptail --msgbox "🔁 Serveri käynnistettiin uudelleen onnistuneesti." 10 60
    else
      whiptail --msgbox "❌ Uudelleenkäynnistyksessä tapahtui virhe." 10 60
    fi
    ;;
  0) ;;
esac
